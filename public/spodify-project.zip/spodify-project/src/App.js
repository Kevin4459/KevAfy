import logo from './logo.svg';
import './App.css';
import React from 'react';
import ReactAudioPlayer from 'react-audio-player';
  // import { Song } from './Songs';
// import TrackList from './Songs/TrackList.js'

const {
  REACT_APP_CLIENT_ID: CLIENT_ID,
  REACT_APP_REDIRECT_URI: REDIRECT_URI,
  REACT_APP_AUTH_ENDPOINT: AUTH_ENDPOINT,
  REACT_APP_RESPONSE_TYPE: RESPONSE_TYPE
} = process.env;
const spotifyAuthURI = `${AUTH_ENDPOINT}?client_id=${CLIENT_ID}&redirect_uri=${REDIRECT_URI}&response_type=${RESPONSE_TYPE}`;

class App extends React.Component {

  constructor(props) {
    super(props)

    this.state = {
      tracks: [],
      currentTrack: null,
    }
  }

  searchSongs = async (q) => {
    const params = {
      q: "22gz",
      type: "track",
    };
    try {
      const queryParams = new URLSearchParams(params);
      const spotifySearchURL =
        "https://api.spotify.com/v1/search?" + queryParams;
      const response = await fetch(spotifySearchURL, {
        headers: {
          Authorization: `Bearer ${window.localStorage.getItem("token")}`,
        },
      });
      const tracks = await response.json();
      console.log(tracks.tracks.items);
      this.setState({ tracks: tracks.tracks.items });
    } catch (error) {
      console.log(error);
      window.localStorage.removeItem("token");
      window.location.assign(spotifyAuthURI);
    }
  };

  componentDidMount = async () => {
    

    const hash = window.location.hash;
    let token = window.localStorage.getItem("token");
    if (token) {
      this.searchSongs();
    }
    else {
      if (hash === "") {
        window.location.assign(spotifyAuthURI)
      }
      else {
        const access_token =  hash.slice(1).split('&')[0].split('=')[1]
        window.localStorage.setItem("token", access_token)
        window.location.assign(REDIRECT_URI);
      }
    }
  };

  render() {
    return (
      <div>
        <h1>{this.props.name}</h1>
        <br />
        <div align="center">
          <input placeholder="search"/>
        </div>
        <ReactAudioPlayer src={this.state.currentTrack} controls autoPlay/>
       {this.state.tracks.map(track => {
      return (
        <div align="center">
          <img src={track.album.images[0].url} width="30%" />
          <h1>{track.name}</h1>
          <button onClick={ ()=> this.setState({currentTrack: track.preview_url})}>Play</button><button>Stop</button>
          <h3>Release date:{track.album.release_date}</h3>
        </div>
      )
    })}
    </div>
    )
  }
}

export default App;
